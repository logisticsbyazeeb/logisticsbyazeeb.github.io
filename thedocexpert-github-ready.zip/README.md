# The Doc Expert — GitHub Pages

Static, responsive website for `thedocexpert.ae`.

## Structure

```text
thedocexpert/
├── index.html
├── styles.css
├── script.js
├── README.md
└── assets/
    └── logo.jpeg
```

## Publish with GitHub Pages

1. Create a new GitHub repository.
2. Upload all files/folders from this project.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then save.
6. Add the custom domain `thedocexpert.ae` in Pages settings.
7. At your domain/DNS provider, point the domain to the GitHub Pages address shown by GitHub.
8. Enable HTTPS after the DNS record has propagated.

## Before going live

- Replace the placeholder WhatsApp number in `index.html`.
- Confirm the displayed email and business details.
- Review service wording and any regulatory/company-status statements.
- Replace the abstract hero artwork with an approved logistics/JAFZA photo if desired.
